package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a byte[] column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class BytesColumn extends Column {
    private byte[] value;

    public BytesColumn(String name, byte[] value) {
        super(name);
        this.value = value;
    }

    public byte[] getBytes() {
        return value;
    }

    public String getString() {
        return new String(value);
    }
}
