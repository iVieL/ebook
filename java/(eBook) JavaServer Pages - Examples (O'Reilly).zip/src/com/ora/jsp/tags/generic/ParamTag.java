package com.ora.jsp.tags.generic;

import java.net.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * This class is a custom action intended to be used in the body of
 * an EncodeURLTag or a RedirectTag. It adds the specified parameter
 * name and value to it's parent's list of parameters. It can be
 * used in the body of any tag handler that implements the ParamParent
 * interface.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class ParamTag extends TagSupport {
    private String name;
    private String value;

    /**
     * Sets the name attribute.
     *
     * @param name the parameter name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the value attribute from a String.
     *
     * @param value the parameter String value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Adds the parameter name and the URL encoded value to the
     * parent's parameter list.
     */
    public int doEndTag() throws JspException {
        Tag parent = findAncestorWithClass(this, ParamParent.class);
        if (parent == null) {
            throw new JspException("The param action is not " +
                "enclosed by a supported action type");
        }
        ParamParent paramParent = (ParamParent) parent;
        paramParent.setParam(name, URLEncoder.encode(value));
        return EVAL_PAGE;
    }
    
    /**
     * Releases all instance variables.
     */
    public void release() {
        name = null;
        value = null;
        super.release();
    }
}