main()
{
    extern char *y_();
    char s[15];

    y_(s, 15L);
}

x_(s, len)
char *s;
long len;
{
    s[0] = 'a';
    s[1] = 'b';
    s[2] = 'c';
    s[3] = 'd';
    s[4] = 'e';
    s[5] = 'f';
    s[6] = 'g';
    s[7] = 'h';
    s[8] = 'i';
    s[9] = 'j';
    s[10] = 'k';
    s[11] = 'l';
    s[12] = 'm';
    s[13] = 'n';
    s[14] = 'o';
}

