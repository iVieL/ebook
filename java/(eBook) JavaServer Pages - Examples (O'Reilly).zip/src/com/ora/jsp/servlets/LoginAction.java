package com.ora.jsp.servlets;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * This class handles forward to the login page in the Project Billboard
 * application.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class LoginAction implements Action {
    private ActionUtils utils = new ActionUtils();

    /**
     * Get the originally requested URL, with a possible query string,
     * and passes it on as a parameter when forwarding to the login
     * page, along with a message about why the requested page is
     * not displayed.
     */
    public void perform(HttpServlet servlet, HttpServletRequest request,
        HttpServletResponse response) throws IOException, ServletException {
        String origURL = HttpUtils.getRequestURL(request).toString();
        String queryString = request.getQueryString();
        if (queryString != null) {
            origURL += "?" + queryString;
        }
        String loginURL = "login.jsp" + "?origURL=" + 
            URLEncoder.encode(origURL) +
            "&errorMsg=" + URLEncoder.encode("Please log in first");
        utils.forward(loginURL, request, response);
    }
}