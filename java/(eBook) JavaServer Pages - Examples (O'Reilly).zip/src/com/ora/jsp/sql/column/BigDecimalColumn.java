package com.ora.jsp.sql.column;

import java.math.*;
import com.ora.jsp.sql.Column;

/**
 * This class represents a BigDecimal column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class BigDecimalColumn extends Column {
    private BigDecimal value;

    public BigDecimalColumn(String name, BigDecimal value) {
        super(name);
        this.value = value;
    }

    public BigDecimal getBigDecimal() {
        return value;
    }

    public String getString() {
        return value.toString();
    }
}