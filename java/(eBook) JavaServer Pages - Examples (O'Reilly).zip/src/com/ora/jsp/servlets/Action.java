package com.ora.jsp.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * This interface must be implemented by all Action objects
 * used to process requests in the Project Billboard application.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public interface Action {
    /**
     * Perform the action implemented by the class. This method
     * gives access to exectly the same information as a servlet
     * has access to, since in a way, an Action is just an extension
     * of a servlet.
     */
    public void perform(HttpServlet servlet, HttpServletRequest request,
        HttpServletResponse response) throws IOException, ServletException;    
}