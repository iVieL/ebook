package com.ora.jsp.beans.shopping;

import java.io.*;
import java.util.*;

/**
 * This class represents a product catalog. It holds a list of
 * products available for sale.
 * <p>
 * This is just a demo so the product list is hardcoded, created
 * at instantiation. A real version would get the information from
 * an external data source.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class CatalogBean implements Serializable {
    private Vector catalog = new Vector();

    /**
     * Constructor. Creates all ProductBean objects and adds them
     * to the catalog.
     */
    public CatalogBean() {
        ProductBean prod = new ProductBean();
        prod.setId("1");
        prod.setName("JavaServer Pages");
        prod.setDescr("Learn how to develop a JSP based web application.");
        prod.setPrice(32.95f);
        catalog.addElement(prod);

        prod = new ProductBean();
        prod.setId("2");
        prod.setName("Java Servlet Programming");
        prod.setDescr("Learn how to develop a servlet based web application.");
        prod.setPrice(32.95f);
        catalog.addElement(prod);

        prod = new ProductBean();
        prod.setId("3");
        prod.setName("Java In a Nutshell");
        prod.setDescr("Learn the Java programming language.");
        prod.setPrice(32.95f);
        catalog.addElement(prod);
    }

    /**
     * Returns a list of all products.
     *
     * @return a Enumeration with ProductBean elements
     */
    public Enumeration getProductList() {
        return catalog.elements();
    }

    /**
     * Returns one product, or throws an exception if not found
     *
     * @param id the product id. The String version is to be able
     *   to use the useProperty action
     * @return a ProductBean
     * @exception Exception if the id doesn't match a product
     */
    public ProductBean getProduct(String id) throws Exception {
        boolean isFound = false;
        ProductBean product = null;
        Enumeration prods = getProductList();
        while (prods.hasMoreElements()) {
            product = (ProductBean) prods.nextElement();
            if (product.getId().equals(id)) {
                isFound = true;
                break;
            }
        }
        if (!isFound) {
            throw new Exception("Product id " + id + " doesn't match a product");
        }
        return product;
    }
}
