hello_()  /* note underscore */
{
	printf("Hello, world.\n");
}
