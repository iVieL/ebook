package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a long column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class LongColumn extends Column {
    private long value;

    public LongColumn(String name, long value) {
        super(name);
        this.value = value;
    }

    public long getLong() {
        return value;
    }

    public String getString() {
        return String.valueOf(value);
    }
}
