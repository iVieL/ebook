package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a short column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class ShortColumn extends Column {
    private short value;

    public ShortColumn(String name, short value) {
        super(name);
        this.value = value;
    }

    public short getShort() {
        return value;
    }

    public String getString() {
        return String.valueOf(value);
    }
}
