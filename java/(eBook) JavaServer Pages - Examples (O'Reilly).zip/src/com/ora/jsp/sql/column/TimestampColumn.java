package com.ora.jsp.sql.column;

import java.sql.*;
import com.ora.jsp.sql.Column;

/**
 * This class represents a Timestamp column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class TimestampColumn extends Column {
    private Timestamp value;

    public TimestampColumn(String name, Timestamp value) {
        super(name);
        this.value = value;
    }

    public Timestamp getTimestamp() {
        return value;
    }

    public String getString() {
        return value.toString();
    }
}
