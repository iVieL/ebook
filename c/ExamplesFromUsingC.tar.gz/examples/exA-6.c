main()
{
    extern y_();
    long a, b, c;

    a = 4;
    b = 5;
    c = 6;

    y_(&a, &b, &c);
}

x_(u, v, w)
long *u, *v, *w;
{
    *u *= 2;
    *v *= 3;
    *w *= 4;
}
