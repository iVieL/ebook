package com.ora.jsp.servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.ora.jsp.beans.emp.*;

/**
 * This class updates a user profile in the Project Billboard
 * application.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class UpdateProfileAction implements Action {
    private ActionUtils utils = new ActionUtils();

    /**
     * Updates the projects property of an authenticated user,
     * represented by the "validUser" session attribute, using
     * the EmployeeRegistryBean. This action is only performed
     * for POST requests. Before returning, the client is
     * redirected to the main page, where the new set of projects
     * are displayed.
     */
    public void perform(HttpServlet servlet, HttpServletRequest request,
        HttpServletResponse response) throws IOException, ServletException {
        if (request.getMethod().equals("POST")) {
            String[] projects = request.getParameterValues("projects");
            if (projects == null) {
                projects = new String[0];
            }
            HttpSession session = request.getSession();
            EmployeeBean emp = 
                (EmployeeBean) session.getAttribute("validUser");
            emp.setProjects(projects);
            EmployeeRegistryBean empReg = (EmployeeRegistryBean) 
                servlet.getServletContext().getAttribute("empReg");
            try {
                empReg.saveEmployee(emp);
            }
            catch (SQLException e) {
                throw new ServletException("Database error", e);
            }
        }
        response.sendRedirect(utils.getShowPageURL(request, "main.jsp"));
    }
}