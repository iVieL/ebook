November 21, 2000

Readme and License for the JavaServer Pages example package
-----------------------------------------------------------

This package contains all JSP application examples and the source
code for all Java classes described in the JavaServer Pages (O'Reilly)
book by Hans Bergsten.

The examples are located in the "ora" directory in a format supported 
by most Servlet 2.2 compliant containers (the Web Application Archive 
structure as an open file system structure). For the Tomcat container, 
all you have to do to install it is to copy the directory under Tomcat's 
"webapps" directory and restart the server.

The "src" directory contains all source code for the Java classes (beans, 
custom action tag handlers, etc.) used in the examples.

You can use the examples and the source code any way you want, but
please include a reference to where it comes from if you use it in
your own products or services. Also note that this software is
provided by the author "as is", with no expressed or implied warranties. 
In no event shall the author be liable for any direct or indirect
damages arising in any way out of the use of this software.

The XSL example (Chapter 12) includes software developed by the Apache 
Software Foundation (http://www.apache.org/). More specifically, the 
Xalan XSLT stylesheet processor and the Xerces XML parser from the 
Apache XML project (http://xml.apache.org/), and the XSL tag library 
from the Apache Jakarta project (http://jakarta.apache.org). The licenses 
for the ASF software is available in the asf-xml-license.txt and the 
asf-jakarta-license.txt documents respectively.
