package com.ora.jsp.tags.sql.value;

import java.lang.reflect.*;
import java.text.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.value.*;
import com.ora.jsp.util.*;
import com.ora.jsp.tags.sql.ValueTagParent;
import com.ora.jsp.util.*;

/**
 * This class is a custom action intended to be used in the body of
 * a sqlQuery or an sqlUpdate action element. It adds the specified 
 * value to its parent's value list.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class StringValueTag extends ValueTag {
    private String value;
    private String prefix;
    private String suffix;

    /**
     * Sets the value property.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Sets the prefix property.
     */
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    /**
     * Sets the suffix property.
     */
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    /**
     * Gets the value, specified by the value attribute, the stringValue
     * attribute, the param attribute, or the name and property attributes,
     * and adds it to the parent's value list. 
     */
    public int doEndTag() throws JspException {
        if (param != null) {
            value = getParameter(param);
        }
        else if (name != null) {
            value = getString(name, property);
        }
        ValueTagParent parent = 
            (ValueTagParent) findAncestorWithClass(this, ValueTagParent.class);
        if (parent == null) {
            throw new JspException("The sqlStringValue action is not " +
                "enclosed by a supported action type");
        }
        // Add prefix and suffix, of any
        value = (prefix != null ? prefix : "") + value +
            (suffix != null ? suffix : "");
        parent.addValue(new StringValue(value));
        return EVAL_PAGE;
    }
    
    /**
     * Releases all instance variables.
     */
    public void release() {
        value = null;
        prefix = null;
        suffix = null;
        super.release();
    }
    
    private String getString(String beanName, String propertyName) 
        throws JspException {
        String stringValue = null;
        Object bean = getBean(beanName);
        Method readMethod = getPropertyReadMethod(bean, propertyName);
        Class returnType = readMethod.getReturnType();
        Object value = getValue(bean, readMethod, propertyName);
        
        if (String.class.isAssignableFrom(returnType)) {
            stringValue = (String) value;
        }
        else {
            throw new JspException("Read method for the " + propertyName +
                " property in the bean named " + beanName + " is not of type " +
                " String");
        }
        return stringValue;
    }
}