#include <signal.h>

main()
{
    /*
     * Declare handler routine so we can use its
     * name.
     */
    extern int handler();

    /*
     * Send signal to handler routine.
     */
    signal(SIGINT, handler);

    /*
     * Loop here.
     */
    for (;;)
        pause();
}

/*
 * handler--handle the signal.
 */
handler()
{
    /*
     * Users of 4.2 and 4.3BSD systems should un-comment
     * this line, which will make this program
     * behave as if it were on a non-Berkeley system.
     */
    /* signal(SIGINT, SIG_DFL); */

    printf("OUCH\n");

    /*
     * Reset the signal to come here again.
     */
    signal(SIGINT, handler);
}

