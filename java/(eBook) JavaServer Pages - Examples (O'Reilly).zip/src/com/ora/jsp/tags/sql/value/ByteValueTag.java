package com.ora.jsp.tags.sql.value;

import java.lang.reflect.*;
import java.text.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.value.*;
import com.ora.jsp.tags.sql.ValueTagParent;
import com.ora.jsp.util.*;

/**
 * This class is a custom action intended to be used in the body of
 * a sqlQuery or an sqlUpdate action element. It adds the specified 
 * value to its parent's value list.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0.1
 */
public class ByteValueTag extends ValueTag {
    private byte value;

    /**
     * Sets the value property.
     */
    public void setValue(byte value) {
        this.value = value;
    }

    /**
     * Gets the value, specified by the value attribute, the stringValue
     * attribute, the param attribute, or the name and property attributes,
     * and adds it to the parent's value list. 
     */
    public int doEndTag() throws JspException {
        if (stringValue != null) {
            value = toByte(stringValue);
        }
        else if (param != null) {
            String paramValue = getParameter(param);
            value = toByte(paramValue);
        }
        else if (name != null) {
            value = getByte(name, property);
        }
        ValueTagParent parent = 
            (ValueTagParent) findAncestorWithClass(this, ValueTagParent.class);
        if (parent == null) {
            throw new JspException("The sqlByteValue action is not " +
                "enclosed by a supported action type");
        }
        parent.addValue(new ByteValue(value));
        return EVAL_PAGE;
    }
    
    private byte toByte(String stringValue) 
        throws JspException {
        if (stringValue.length() == 0) {
            throw new JspException("An empty string can not be converted to " +
                " a byte.");
        }
        byte[] bytes = stringValue.getBytes();
        return bytes[0];
    }
    
    private byte getByte(String beanName, String propertyName) 
        throws JspException {
        byte byteValue;
        Object bean = getBean(beanName);
        Method readMethod = getPropertyReadMethod(bean, propertyName);
        Class returnType = readMethod.getReturnType();
        Object value = getValue(bean, readMethod, propertyName);
        
        if (Byte.TYPE.isAssignableFrom(returnType)) {
            byteValue = ((Byte) value).byteValue();
        }
        else if (String.class.isAssignableFrom(returnType)) {
            byteValue = toByte((String) value);
        }
        else {
            throw new JspException("Read method for the " + propertyName +
                " property in the bean named " + beanName + " is not of type " +
                " String or byte");
        }
        return byteValue;
    }
}
