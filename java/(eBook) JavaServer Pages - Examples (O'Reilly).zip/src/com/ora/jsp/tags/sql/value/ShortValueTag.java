package com.ora.jsp.tags.sql.value;

import java.lang.reflect.*;
import java.text.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.value.*;
import com.ora.jsp.tags.sql.ValueTagParent;
import com.ora.jsp.util.*;

/**
 * This class is a custom action intended to be used in the body of
 * a sqlQuery or an sqlUpdate action element. It adds the specified 
 * value to its parent's value list.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0.1
 */
public class ShortValueTag extends ValueTag {
    private short value;

    /**
     * Sets the value property.
     */
    public void setValue(short value) {
        this.value = value;
    }

    /**
     * Gets the value, specified by the value attribute, the stringValue
     * attribute, the param attribute, or the name and property attributes,
     * and adds it to the parent's value list. If the value is a String
     * and a pattern attribute is specified, the String is converted
     * into the appropriate type before being added to the parent's
     * value list.
     */
    public int doEndTag() throws JspException {
        if (stringValue != null) {
            value = toShort(stringValue, pattern);
        }
        else if (param != null) {
            String paramValue = getParameter(param);
            value = toShort(paramValue, pattern);
        }
        else if (name != null) {
            value = getShort(name, property, pattern);
        }
        ValueTagParent parent = 
            (ValueTagParent) findAncestorWithClass(this, ValueTagParent.class);
        if (parent == null) {
            throw new JspException("The sqlShortValue action is not " +
                "enclosed by a supported action type");
        }
        parent.addValue(new ShortValue(value));
        return EVAL_PAGE;
    }
    
    private short toShort(String stringValue, String pattern) 
        throws JspException {
        short shortValue;
        try {
            Number number = StringFormat.toNumber(stringValue, pattern);
            shortValue = number.shortValue();
        }
        catch (ParseException e) {
            throw new JspException(stringValue + " can not be converted to " +
                " a short using pattern: " + pattern + ". Message: " +
                e.getMessage());
        }
        return shortValue;
    }
    
    private short getShort(String beanName, String propertyName,
        String pattern) throws JspException {
        short shortValue;
        Object bean = getBean(beanName);
        Method readMethod = getPropertyReadMethod(bean, propertyName);
        Class returnType = readMethod.getReturnType();
        Object value = getValue(bean, readMethod, propertyName);
        
        if (Short.TYPE.isAssignableFrom(returnType)) {
            shortValue = ((Short) value).shortValue();
        }
        else if (String.class.isAssignableFrom(returnType)) {
            shortValue = toShort((String) value, pattern);
        }
        else {
            throw new JspException("Read method for the " + propertyName +
                " property in the bean named " + beanName + " is not of type " +
                " String or short");
        }
        return shortValue;
    }
}
