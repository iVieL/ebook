package com.ora.jsp.servlets;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;
import com.ora.jsp.beans.emp.*;
import com.ora.jsp.beans.news.*;
import com.ora.jsp.sql.*;

/**
 * This class acts as a controller for the Project Billboard
 * example, dispatching to separate Action objects for request
 * processing.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class PBDispatcherServlet extends HttpServlet {
    private Hashtable actions;

    /**
     * Creates the application scope objects used by the Actions
     * and JSP pages in this application. 
     * <p>
     * Note! In this example, a DataSource object is created using 
     * hardcoded information. In a real application, it should be 
     * retrieved through JNDI or created based on configurable 
     * information if JNDI is not used. If the application contains
     * more than one servlet, it may also be better to do all
     * initialization in a servlet dedicated to setting up the
     * application environment instead.
     */
    public void init() throws ServletException {
        DataSource ds = null;
        try {
            ds = new DataSourceWrapper("sun.jdbc.odbc.JdbcOdbcDriver", 
                "jdbc:odbc:example", null, null);
        }
        catch (Exception e) {} // Ignore all in this example
        EmployeeRegistryBean empReg = new EmployeeRegistryBean();
        empReg.setDataSource(ds);
        getServletContext().setAttribute("empReg", empReg);

        NewsBean news = new NewsBean();
        getServletContext().setAttribute("news", news);
        initActions();
    }
    
    /**
     * Removes the EmployeeRegistryBean and NewsBean
     * servlet context attributes.
     */
    public void destroy() {
        getServletContext().removeAttribute("empReg");
        getServletContext().removeAttribute("news");
    }
    
    /**
     * Performs the same processing as for a POST request.
     */
    public void doGet(HttpServletRequest request, 
        HttpServletResponse response) 
        throws IOException, ServletException {
        doPost(request, response);
    }
    
    /**
     * Locates the Action object corresponding to the requested
     * action, or the login Action in case the user is not yet
     * authenticated, and dispatch the processing to the selected
     * Action object.
     */
    public void doPost(HttpServletRequest request, 
        HttpServletResponse response) 
        throws IOException, ServletException {
        
        String actionName = request.getParameter("action");
        if (actionName == null) {
            response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
            return;
        }
        
        Action action = (Action) actions.get(actionName);
        if (action == null) {
            response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED);
            return;
        }
        
        // Use the login action if the user is not authenticated
        if (!isAuthenticated(request) && 
            !("authenticate".equals(actionName) || 
	      "logout".equals(actionName))) {
            action = (Action) actions.get("login");
        }
        action.perform(this, request, response);
    }
    
    /**
     * Initializes the set of Action objects used by the
     * application. Instead of hardcoding this list, it can
     * be based on configuration information, such as
     * servlet initialization parameters.
     */
    private void initActions() {
        actions = new Hashtable();
        actions.put("authenticate", new AuthenticateAction());
        actions.put("logout", new LogoutAction());
        actions.put("storeMsg", new StoreMsgAction());
        actions.put("updateProfile", new UpdateProfileAction());
        actions.put("showPage", new ShowPageAction());
        actions.put("login", new LoginAction());
    }
 
    /**
     * Returns true if the session contains the authentication token.
     */
    private boolean isAuthenticated(HttpServletRequest request) {
        boolean isAuthenticated = false;
        HttpSession session = request.getSession();
        if (session.getAttribute("validUser") != null) {
            isAuthenticated = true;
        }
        return isAuthenticated;
    }
}
