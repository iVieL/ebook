package com.ora.jsp.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.ora.jsp.beans.emp.*;
import com.ora.jsp.beans.news.*;

/**
 * This class stores a new message in the Project Billboard
 * application.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class StoreMsgAction implements Action {
    private ActionUtils utils = new ActionUtils();

    /**
     * Creates a new NewsItemBean and sets its properties based
     * on the "category" and "msg" request parameters, plus
     * the firstName and lastName properties of the authenticated
     * user (an EmployeeBean accessible as the "validUser" session
     * attribute). The NewItemBean is then added to the NewsBean.
     * This action is only performed for POST request.
     * Before returning, the client is redirected to the main page, 
     * where the new message is displayed.
     */
    public void perform(HttpServlet servlet, HttpServletRequest request,
        HttpServletResponse response) throws IOException, ServletException {
        if (request.getMethod().equals("POST")) {
            String category = request.getParameter("category");
            String msg = request.getParameter("msg");
            if (category == null || msg == null) {
                throw new ServletException("Missing message info");
            }
            HttpSession session = request.getSession();
            EmployeeBean emp = 
                (EmployeeBean) session.getAttribute("validUser");
            NewsItemBean item = new NewsItemBean();
            item.setCategory(category);
            item.setMsg(msg);
            item.setPostedBy(emp.getFirstName() + " " +
                emp.getLastName());
            NewsBean news = (NewsBean)
                servlet.getServletContext().getAttribute("news");
            news.setNewsItem(item);
        }
        response.sendRedirect(utils.getShowPageURL(request, "main.jsp"));
    }
}