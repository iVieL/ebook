package com.ora.jsp.tags.sql;

import java.util.*;
import java.sql.*;
import javax.sql.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.*;
import com.ora.jsp.sql.value.*;

/**
 * This class is a custom action for executing a SQL INSERT, UPDATE and
 * DELETE statements, as well as SQL DDL statements (e.g. CREATE TABLE).
 * The statement must be defined in the body of the action. It can
 * contain ? place holders, replaced by the value of <ora:sqlValue>
 * elements before execution. The number and order of place holders must
 * match the number and order of <ora:sqlValue> elements in the body.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class UpdateTag extends DBTag {
    /**
     * Executes the SQL command as an "update" and returns an Integer
     * with the number of rows affected.
     *
     * @param sqlCommandBean the SQL command to execute
     * @return the number of rows affected as an Integer
     */
    public Object execute(SQLCommandBean sqlCommandBean)
        throws SQLException, UnsupportedTypeException {
        return new Integer(sqlCommandBean.executeUpdate());
    }
}