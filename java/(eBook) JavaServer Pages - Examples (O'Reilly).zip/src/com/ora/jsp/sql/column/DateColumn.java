package com.ora.jsp.sql.column;

import java.sql.*;
import com.ora.jsp.sql.Column;

/**
 * This class represents a java.sql.Date column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class DateColumn extends Column {
    private Date value;

    public DateColumn(String name, Date value) {
        super(name);
        this.value = value;
    }

    public Date getDate() {
        return value;
    }

    public String getString() {
        return value.toString();
    }
}
