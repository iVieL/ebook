package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents an Object column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class ObjectColumn extends Column {
    private Object value;

    public ObjectColumn(String name, Object value) {
        super(name);
        this.value = value;
    }

    public Object getObject() {
        return value;
    }

    public String getString() {
        return value.toString();
    }
}
