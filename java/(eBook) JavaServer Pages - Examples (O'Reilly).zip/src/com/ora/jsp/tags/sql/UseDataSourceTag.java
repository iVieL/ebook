package com.ora.jsp.tags.sql;

import java.util.*;
import java.sql.*;
import javax.sql.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.*;

/**
 * This class is a custom action for making the JDBC 1.0 DriverManager
 * available to the other Database actions as a JDBC 2.0 SE DataSource,
 * saved in the application scope.
 * It's intended to be used only during development. In production,
 * it's much more efficient to let an application init servlet make
 * a DataSource that implements a connection pool available to the
 * other actions.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class UseDataSourceTag extends TagSupport {
    private String id;
    private String driverClassName;
    private String url;
    private String user;
    private String pw;

    /**
     * Sets the id, i.e. the name to use for the DataSource
     * in one of the JSP scopes.
     */
    public void setId(String id) {
        this.id = id;
    }
    
    /**
     * Sets the JDBC driver class name.
     */
    public void setClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }
    
    /**
     * Sets the JDBC URL.
     */
    public void setUrl(String url) {
        this.url = url;
    }
    
    /**
     * Sets the database account name, if needed.
     */
    public void setUser(String user) {
        this.user = user;
    }
    
    /**
     * Sets the database account password, if needed.
     */
    public void setPw(String pw) {
        this.pw = pw;
    }

    /**
     * Creates a DataSourceWrapper and saves it in the application
     * scope, unless one is already available.
     */
    public int doEndTag() throws JspException {
        DataSource ds = (DataSource)
            pageContext.getAttribute(id, PageContext.APPLICATION_SCOPE);
        if (ds == null) {
            try {
                ds = new DataSourceWrapper(driverClassName, url, user, pw); 
            }
            catch (Exception e) {
                throw new JspException("Can't create DataSource: " + e.getMessage());
            }
            pageContext.setAttribute(id, ds, PageContext.APPLICATION_SCOPE);
        }
        return EVAL_PAGE;
    }
    
    /**
     * Releases all instance variables.
     */
    public void release() {
        id = null;
        driverClassName = null;
        url = null;
        user = null;
        pw = null;
    }
}