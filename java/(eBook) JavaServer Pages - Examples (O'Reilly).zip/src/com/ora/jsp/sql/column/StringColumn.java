package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a String column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class StringColumn extends Column {
    private String value;

    public StringColumn(String name, String value) {
        super(name);
        this.value = value;
    }

    public String getString() {
        return value;
    }
}
