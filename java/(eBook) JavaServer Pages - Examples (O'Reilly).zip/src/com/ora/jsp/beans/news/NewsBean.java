package com.ora.jsp.beans.news;

import java.io.*;
import java.util.*;
import com.ora.jsp.util.*;

/**
 * This class maintains a list of NewsItemBean objects. It's
 * only intended as an example. A real implementation would
 * use a database to keep track of the objects instead.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class NewsBean implements Serializable {
    private Vector newsItems = new Vector();
    private int[] idSequence = new int[1];
    
    /**
     * Creates a new instance and fills it with a few sample
     * news items.
     */
    public NewsBean() {
        addDefaultItems();
    }
    
    /**
     * Returns an array of all items in the specified categories.
     */
    public NewsItemBean[] getNewsItems(String[] categories) {
        Vector matches = new Vector();
        synchronized (newsItems) {
            for (int i = 0; i < newsItems.size(); i++) {
                NewsItemBean item = (NewsItemBean) newsItems.elementAt(i);
                if (ArraySupport.contains(categories, item.getCategory())) {
                    matches.addElement(item);
                }
            }
        }
        NewsItemBean[] matchingItems = new NewsItemBean[matches.size()];
        matches.copyInto(matchingItems);
        return matchingItems;
    }

    /**
     * Adds a news item to the list.
     */
    public void setNewsItem(NewsItemBean newsItem) {
        synchronized (idSequence) {
            newsItem.setId(idSequence[0]++);
        }
        newsItems.addElement(newsItem);
    }
    
    /**
     * Removes the new item with the specified id.
     */
    public void removeNewsItem(int id) {
        synchronized (newsItems) {
            for (int i = 0; i < newsItems.size(); i++) {
                NewsItemBean item = (NewsItemBean) newsItems.elementAt(i);
                if (id == item.getId()) {
                    newsItems.removeElementAt(i);
                    break;
                }
            }
        }
    }
    
    /**
     * Creates sample news items and adds them to the list.
     */
    private void addDefaultItems() {
        NewsItemBean item = new NewsItemBean();
        item.setCategory("JSP");
        item.setMsg("New O'Reilly JSP book released!");
        item.setPostedBy("Hans Bergsten");
        setNewsItem(item);
        
        item = new NewsItemBean();
        item.setCategory("Servlet");
        item.setMsg("Servets and JSP is a great combination.");
        item.setPostedBy("Hans Bergsten");
        setNewsItem(item);
        
        item = new NewsItemBean();
        item.setCategory("EJB");
        item.setMsg("JSP makes a great front-end for EJB.");
        item.setPostedBy("Hans Bergsten");
        setNewsItem(item);
    }
}