package com.ora.jsp.tags.generic;

import java.io.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.util.*;

/**
 * This class is a custom action for writing the value of a
 * cookie to the response.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class GetCookieValueTag extends TagSupport {
    private String name;

    /**
     * Sets the cookie name attribute.
     *
     * @param name the name of the cookie
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Writes the specified cookie value to the output stream,
     * or an empty string if not found.
     */
    public int doEndTag() throws JspException {
        String value =
            CookieUtils.getCookieValue(name, 
                (HttpServletRequest) pageContext.getRequest());
        if (value == null) {
            value = "";
        }
        try {
            pageContext.getOut().write(value);
        }
        catch (IOException e) {} // Ignore it
        return EVAL_PAGE;
    }
    
    /**
     * Releases all instance variables.
     */
    public void release() {
        name = null;
        super.release();
    }
}
