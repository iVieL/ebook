package com.ora.jsp.tags.sql;

import com.ora.jsp.sql.*;

/**
 * This interface must be implemented by all Tag's that can
 * have ValueTag's in the body.
 */
public interface ValueTagParent {
    /**
     * Adds a to the value list
     */
    void addValue(Value value);
}