package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a double column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class DoubleColumn extends Column {
    private double value;

    public DoubleColumn(String name, double value) {
        super(name);
        this.value = value;
    }

    public double getDouble() {
        return value;
    }

    public String getString() {
        return String.valueOf(value);
    }
}
