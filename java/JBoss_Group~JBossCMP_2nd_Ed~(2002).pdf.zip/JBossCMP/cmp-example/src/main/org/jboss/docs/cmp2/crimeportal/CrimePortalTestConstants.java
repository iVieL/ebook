package org.jboss.docs.cmp2.crimeportal;

public interface CrimePortalTestConstants {
   public final Integer YOJIMBO = new Integer(0); 
   public final Integer TAKESHI = new Integer(1); 
   public final Integer YURIKO = new Integer(2); 
   public final Integer CHOW = new Integer(3); 
   public final Integer SHOGI = new Integer(4); 
   public final Integer VALENTINO = new Integer(5); 
   public final Integer TONI = new Integer(6); 
   public final Integer CORLEONE = new Integer(7); 
}

