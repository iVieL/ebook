package com.ora.jsp.tags.sql;

import java.util.*;
import java.sql.*;
import javax.sql.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.sql.*;
import com.ora.jsp.sql.value.*;

/**
 * This class is a custom action for executing a SQL SELECT statement.
 * The statement must be defined in the body of the action. It can
 * contain ? place holders, replaced by the value of <ora:sqlValue>
 * elements before execution. The number and order of place holders must
 * match the number and order of <ora:sqlValue> elements in the body.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class QueryTag extends DBTag {
    /**
     * Executes the SQL command as a query and returns a Vector
     * with Row objects.
     *
     * @param sqlCommandBean the SQL command to execute
     * @return a Vector with Row objects
     */
    public Object execute(SQLCommandBean sqlCommandBean) 
        throws SQLException, UnsupportedTypeException {
        return sqlCommandBean.executeQuery();
    }
}