package com.ora.jsp.tags.counter;

import java.io.*;
import java.util.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.beans.counter.*;

/**
 * This class is a custom action for showing the current value of
 * a page counter for the page where it's included.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0.1
 */
public class ShowCounterTag extends TagSupport {
    private int scope;

    /**
     * Gets the CounterBean from the specified scope and writes
     * the value of the counter for the current page to the
     * JspWriter.
     */
    public int doEndTag() {
        int value = -1;
        CounterBean counters = (CounterBean)
            pageContext.getAttribute("com.ora.counter", scope);
        HttpServletRequest req = (HttpServletRequest) pageContext.getRequest();
        String uri = req.getRequestURI();
        if (counters != null) {
            value = counters.getCurrentValue(uri);
        }
        try {
            pageContext.getOut().println(value);
        }
        catch (IOException e) {} // Ignore it
    	return EVAL_PAGE;
    }

    /**
     * Sets the scope attribute value.
     *
     * @param scopeName the scope for the counter.
     */
    public void setScope(String scopeName) {
        if ("application".equals(scopeName)) {
            scope = PageContext.APPLICATION_SCOPE;
        }
        else if ("session".equals(scopeName)) {
            scope = PageContext.SESSION_SCOPE;
        }
        else if ("request".equals(scopeName)) {
            scope = PageContext.REQUEST_SCOPE;
        }
        else if ("page".equals(scopeName)) {
            scope = PageContext.PAGE_SCOPE;
        }
    }
}
