package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a int column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class IntColumn extends Column {
    private int value;

    public IntColumn(String name, int value) {
        super(name);
        this.value = value;
    }

    public int getInt() {
        return value;
    }

    public String getString() {
        return String.valueOf(value);
    }
}
