package com.ora.jsp.tags.sql.value;

import java.beans.*;
import java.lang.reflect.*;
import javax.servlet.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * This class is a superclass for custom action classes intended to 
 * be used in the body of a sqlQuery or an sqlUpdate action element. 
 * It provides methods for dealing with common attributes.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class ValueTag extends TagSupport {
    protected String stringValue;
    protected String pattern;
    protected String param;
    protected String name;
    protected String property;

    /**
     * Sets the value as a String.
     */
    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }
    
    /**
     * Sets the parsing pattern for a date/time or a
     * numeric value expressed as a String.
     */
    public void setPattern(String pattern) {
        this.pattern = pattern;
    }
    
    /**
     * Sets the name of the HTTP parameter that holds
     * the value.
     */
    public void setParam(String param) {
        this.param = param;
    }
    
    /**
     * Sets the name of the bean in one of the JSP scopes
     * with a property that holds the value.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Sets the name of the bean property that holds the
     * value.
     */
    public void setProperty(String property) {
        this.property = property;
    }

    /**
     * Releases all instance variables.
     */
    public void release() {
        stringValue = null;
        pattern = null;
        param = null;
        name = null;
        property = null;
        super.release();
    }
    
    /**
     * Returns the value of the specified request parameter, or
     * throws a JspException if it doesn't exist.
     */
    protected String getParameter(String paramName) throws JspException {
        ServletRequest request = pageContext.getRequest();
        String value = request.getParameter(paramName);
        if (value == null) {
            throw new JspException("Parameter " + paramName + " not found");
        }
        return value;
    }
    
    /**
     * Returns the value of the specified bean, or
     * throws a JspException if it doesn't exist.
     */
    protected Object getBean(String beanName) throws JspException {
        Object bean = pageContext.findAttribute(beanName);
        if (bean == null) {
            throw new JspException("Bean named " + beanName + " not found");
        }
        return bean;
    }
        
    /**
     * Returns the read access method for the specified property of
     * the specified bean, or throws a JspException if it doesn't exist.
     */
    protected Method getPropertyReadMethod(Object bean, String propertyName) 
        throws JspException {
        Method readMethod = null;
        BeanInfo beanInfo = null;
        try {
            beanInfo = Introspector.getBeanInfo(bean.getClass());
        }
        catch (IntrospectionException e) {
            throw new JspException("Exception trying to locate the " + propertyName +
                " property in the bean class " + bean.getClass() + ": " +
                e.getMessage());
        }
        PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
        for (int i = 0; pds != null && i < pds.length; i++) {
            if (pds[i].getName().equals(propertyName)) {
                readMethod = pds[i].getReadMethod();
                break;
            }
        }
        if (readMethod == null) {
            throw new JspException("Read method for the " + propertyName +
                " property in the bean class " + bean.getClass() + " not found");
        }
        return readMethod;
    }
    
    /**
     * Invokes the read access method on the specified bean and
     * returns the result, or throws a JspException if it fails.
     */
    protected Object getValue(Object bean, Method readMethod, String propertyName) 
        throws JspException {
        Object value = null;
        try {
            value = readMethod.invoke(bean, null);
        }
        catch (InvocationTargetException ite) {
            throw new JspException("Exception trying to read the " + propertyName +
                " property in the bean class " + bean.getClass() + ": " +
                ite.getMessage());
        }
        catch (IllegalAccessException iae) {
            throw new JspException("Exception trying to read the " + propertyName +
                " property in the bean class " + bean.getClass() + ": " +
                iae.getMessage());
        }
        return value;
    }
}