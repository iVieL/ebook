main()
{
    extern char *y_();
    char *i;

    i = "hi there";
    y_(i, 8L);
}

x_(s, len)
char *s;
long len;
{
    write(1, s, len);
}

