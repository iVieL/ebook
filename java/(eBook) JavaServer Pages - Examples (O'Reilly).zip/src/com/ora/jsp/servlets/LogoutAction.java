package com.ora.jsp.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * This class performs the log out from the Project Billboard
 * application.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class LogoutAction implements Action {
    /**
     * Invalidates the session, thereby removing the authentication
     * token, and redirects to the login page.
     */
    public void perform(HttpServlet servlet, HttpServletRequest request,
        HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        session.invalidate();
        response.sendRedirect("login.jsp");
    }
}