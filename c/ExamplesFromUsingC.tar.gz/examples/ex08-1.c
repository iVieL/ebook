#include <signal.h>

main()
{
    signal(SIGINT, SIG_IGN);

    /*
     * pause() just suspends the process until a
     * signal is received.
     */
    pause();
}

