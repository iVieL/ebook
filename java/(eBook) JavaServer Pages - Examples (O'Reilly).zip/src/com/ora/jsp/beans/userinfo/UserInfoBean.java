package com.ora.jsp.beans.userinfo;

import java.io.*;
import java.util.*;
import com.ora.jsp.util.*;

/**
 * This class contains information about a user. It's used to show
 * how a bean can be used to validate user input and format output
 * so it's suitable for HTML.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class UserInfoBean implements Serializable {
    // Validation constants
    private static String DATE_FORMAT_PATTERN = "yyyy-MM-dd";
    private static String[] SEX_LIST = {"male", "female"};
    private static int MIN_LUCKY_NUMBER = 0;
    private static int MAX_LUCKY_NUMBER = 100;

    // Properties
    private String birthDate;
    private String birthDateInput;
    private String emailAddr;
    private String emailAddrInput;
    private String[] interests;
    private String luckyNumber;
    private String luckyNumberInput;
    private String sex;
    private String sexInput;
    private String userName;
    private boolean isInitialized;

    /**
     * Returns the birthDate property value
     */
    public String getBirthDate() {
        return (birthDate == null ? "" : birthDate);
    }

    /**
     * Returns the birthDate property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String getBirthDateFormatted() {
        return StringFormat.toHTMLString(getBirthDate());
    }

    /**
     * Sets the birthDate property value, if it's
     * valid
     */
    public void setBirthDate(String birthDate) {
        isInitialized = true;
        birthDateInput = birthDate;
        if (StringFormat.isValidDate(birthDate, DATE_FORMAT_PATTERN)) {
            this.birthDate = birthDate;
        }
    }

    /**
     * Returns the emailAddr property value
     */
    public String getEmailAddr() {
        return (emailAddr == null ? "" : emailAddr);
    }

    /**
     * Returns the emailAddr property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String getEmailAddrFormatted() {
        return StringFormat.toHTMLString(getEmailAddr());
    }

    /**
     * Sets the emailAddr property value, if it's
     * valid
     */
    public void setEmailAddr(String emailAddr) {
        isInitialized = true;
        emailAddrInput = emailAddr;
        if (StringFormat.isValidEmailAddr(emailAddr)) {
            this.emailAddr = emailAddr;
        }
    }

    /**
     * Returns the interests property value
     */
    public String[] getInterests() {
        return interests;
    }

    /**
     * Returns the interests property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String[] getInterestsFormatted() {
        String[] formatted = null;
        String[] interests = getInterests();
        if (interests != null) {
            formatted = new String[interests.length];
            for (int i = 0; i < interests.length; i++) {
                formatted[i] = StringFormat.toHTMLString(interests[i]);
            }
        }
        return formatted;
    }

    /**
     * Sets the interests property value
     */
    public void setInterests(String[] interests) {
        this.interests = interests;
    }

    /**
     * Returns the luckyNumber property value
     */
    public String getLuckyNumber() {
        return (luckyNumber == null ? "" : luckyNumber);
    }

    /**
     * Returns the luckyNumber property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String getLuckyNumberFormatted() {
        return StringFormat.toHTMLString(getLuckyNumber());
    }

    /**
     * Sets the luckyNumber property value, if it's
     * valid
     */
    public void setLuckyNumber(String luckyNumber) {
        isInitialized = true;
        luckyNumberInput = luckyNumber;
        if (StringFormat.isValidInteger(luckyNumber, MIN_LUCKY_NUMBER,
            MAX_LUCKY_NUMBER)) {
            this.luckyNumber = luckyNumber;
        }
    }

    /**
     * Returns the sex property value
     */
    public String getSex() {
        return (sex == null ? "" : sex);
    }

    /**
     * Returns the sex property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String getSexFormatted() {
        return StringFormat.toHTMLString(getSex());
    }

    /**
     * Sets the sex property value, if it's
     * valid
     */
    public void setSex(String sex) {
        isInitialized = true;
        sexInput = sex;
        if (StringFormat.isValidString(sex, SEX_LIST, true)) {
            this.sex = sex;
        }
    }

    /**
     * Returns the userName property value
     */
    public String getUserName() {
        return (userName == null ? "" : userName);
    }

    /**
     * Returns the userName property value,
     * with all HTML special characters converted
     * to HTML character entities
     */
    public String getUserNameFormatted() {
        return StringFormat.toHTMLString(getUserName());
    }

    /**
     * Sets the userName property value
     */
    public void setUserName(String userName) {
        isInitialized = true;
        this.userName = userName;
    }

    /**
     * Returns an HTML fragment with information about
     * all invalid property values, or an empty String
     * if all properties are valid.
     */
    public String getPropertyStatusMsg() {
        StringBuffer msg = new StringBuffer();
        if (!isInitialized()) {
            msg.append("Please enter values in all fields");
        }
        else if (!isValid()) {
            msg.append("The following values are missing or invalid: ");
            msg.append("<ul>");
            if (birthDate == null) {
                if (birthDateInput == null) {
                    msg.append("<li>Birth date is missing");
                }
                else {
                    msg.append("<li>Birth date value is invalid: " + birthDateInput);
                }
            }
            if (emailAddr == null) {
                if (emailAddrInput == null) {
                    msg.append("<li>Email address is missing");
                }
                else {
                    msg.append("<li>Email address value is invalid: " + emailAddrInput);
                }
            }
            if (luckyNumber == null) {
                if (luckyNumberInput == null) {
                    msg.append("<li>Lucky number is missing");
                }
                else {
                    msg.append("<li>Lucky number value is invalid: " + luckyNumberInput);
                }
            }
            if (sex == null) {
                if (sexInput == null) {
                    msg.append("<li>Sex is missing");
                }
                else {
                    msg.append("<li>Sex value is invalid: " + sexInput);
                }
            }
            if (userName == null) {
                msg.append("<li>User name is missing");
            }
            msg.append("</ul>");
            msg.append("Please enter new valid values");
        }
        else {
            msg.append("Thanks for telling us about yourself!");
        }
        return msg.toString();
    }

    /**
     * Returns true if all property values have valid values
     * (they are only set if the value is valid).
     */
    public boolean isValid() {
        return isInitialized() &&
            birthDate != null &&
            emailAddr != null &&
            luckyNumber != null &&
            sex != null &&
            userName != null;
    }

    /**
     * Returns true if at least one property has been set
     */
    private boolean isInitialized() {
        return isInitialized;
    }
}





