package com.ora.jsp.tags.counter;

import java.util.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.ora.jsp.beans.counter.*;

/**
 * This class is a custom action for incrementing the value of
 * a page counter for the page where it's included.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0.1
 */
public class IncrementCounterTag extends TagSupport {
    private int scope;

    /**
     * Gets the CounterBean from the specified scope, or creates a
     * new one if it doesn't exist, and increments the value of 
     * the counter for the current page.
     */
    public int doEndTag() {
        CounterBean counters = (CounterBean)
            pageContext.getAttribute("com.ora.counter", scope);
        if (counters == null) {
            counters = new CounterBean();
            pageContext.setAttribute("com.ora.counter", counters, scope);
        }
        HttpServletRequest req = (HttpServletRequest) pageContext.getRequest();
        String uri = req.getRequestURI();
        counters.incrementValue(uri);
    	return EVAL_PAGE;
    }

    /**
     * Sets the scope attribute value.
     *
     * @param scopeName the scope for the counter.
     */
    public void setScope(String scopeName) {
        if ("application".equals(scopeName)) {
            scope = PageContext.APPLICATION_SCOPE;
        }
        else if ("session".equals(scopeName)) {
            scope = PageContext.SESSION_SCOPE;
        }
        else if ("request".equals(scopeName)) {
            scope = PageContext.REQUEST_SCOPE;
        }
        else if ("page".equals(scopeName)) {
            scope = PageContext.PAGE_SCOPE;
        }
    }
}
