package com.ora.jsp.tags.sql.value;

import javax.servlet.jsp.tagext.*;

/**
 * This class provides additional attribute validation code for
 * ValueTag subclasses.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class ValueTagExtraInfo extends TagExtraInfo {
    /**
     * Returns true only if a valid combination of attributes
     * is specified:
     * <pre>
     *   value                   |
     *   stringValue [ pattern ] |
     *   param [ pattern ]       |
     *   name property [ pattern ]
     * </pre>
     */
    public boolean isValid(TagData data) {
        boolean isValid = false;
        Object value = data.getAttribute("value");
        Object stringValue = data.getAttribute("stringValue");
        Object pattern = data.getAttribute("pattern");
        Object param = data.getAttribute("param");
        Object name = data.getAttribute("name");
        Object property = data.getAttribute("property");
        
        if (value != null && 
            (stringValue == null && param == null && pattern == null &&
            name == null && property == null)) {
            isValid = true;
        }
        else if (stringValue != null &&
            (value == null && param == null && name == null &&
            property == null)) {
            isValid = true;
        }
        else if (param != null &&
            (value == null && stringValue == null && name == null &&
            property == null)) {
            isValid = true;
        }
        else if (name != null &&
            (value == null && stringValue == null && param == null &&
            property != null)) {
            isValid = true;
        }
        return isValid;
    }
}
