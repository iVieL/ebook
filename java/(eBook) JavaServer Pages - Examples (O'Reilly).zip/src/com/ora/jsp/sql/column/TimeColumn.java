package com.ora.jsp.sql.column;

import java.sql.*;
import com.ora.jsp.sql.Column;

/**
 * This class represents a Time column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class TimeColumn extends Column {
    private Time value;

    public TimeColumn(String name, Time value) {
        super(name);
        this.value = value;
    }

    public Time getTime() {
        return value;
    }

    public String getString() {
        return value.toString();
    }
}
