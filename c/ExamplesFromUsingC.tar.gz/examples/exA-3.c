main()
{
    extern long y_();
    long i;

    i = y_();
}

long x_()
{
    return(5L);
}
