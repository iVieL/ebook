package com.ora.jsp.sql.column;

import com.ora.jsp.sql.Column;

/**
 * This class represents a float column.
 *
 * @author Hans Bergsten, Gefion software <hans@gefionsoftware.com>
 * @version 1.0
 */
public class FloatColumn extends Column {
    private float value;

    public FloatColumn(String name, float value) {
        super(name);
        this.value = value;
    }

    public float getFloat() {
        return value;
    }

    public String getString() {
        return String.valueOf(value);
    }
}
